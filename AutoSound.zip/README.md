# 🚗 AutoSound - Loja de Som Automotivo

## 📋 Sobre o Projeto

Este é um projeto de **Landing Page** desenvolvido para a disciplina de Desenvolvimento Web.
O tema escolhido foi uma **loja de som automotivo** chamada **AutoSound**.

O projeto consiste em **3 páginas HTML** com navegação entre elas, estilizadas com **CSS puro** (sem JavaScript), seguindo o modelo passado pelo professor.

---

## 📁 Estrutura de Pastas

```
AutoSound/
│
├── index.html              ← Página INÍCIO (na raiz do projeto)
│
├── css/
│   ├── style.css           ← CSS da página INÍCIO + HEADER + FOOTER
│   ├── produtos.css        ← CSS específico da página PRODUTOS
│   └── contatos.css        ← CSS específico da página CONTATOS
│
├── pages/
│   ├── produtos.html       ← Página PRODUTOS
│   └── contatos.html       ← Página CONTATOS
│
└── img/
    └── logo.png            ← Logo da loja (adicionar manualmente)
```

---

## 🎨 Paleta de Cores

| Cor | Hex | Uso |
|-----|-----|-----|
| Laranja | `#FF6B00` | Cor principal (botões, destaques, títulos) |
| Preto | `#1A1A1A` | Fundos escuros (header, footer, hero) |
| Cinza Escuro | `#2D2D2D` | Cards e seções alternativas |
| Branco | `#FFFFFF` | Textos em fundos escuros |
| Cinza Claro | `#F5F5F5` | Fundos de seções claras |
| Cinza Médio | `#888888` | Textos secundários |

---

## 📄 Páginas

### 1️⃣ Início (`index.html`)
- **Hero** com banner principal e botões de ação
- **Sobre** a loja com imagem
- **Estatísticas** (clientes, instalações, produtos vendidos)
- **Serviços** oferecidos (Instalação, Manutenção, Personalização LED)
- **Equipe** (3 membros)

### 2️⃣ Produtos (`pages/produtos.html`)
- Banner de título
- **8 produtos** em grid (4 colunas)
- Seção **"Produtos de Alta Qualidade"**

### 3️⃣ Contatos (`pages/contatos.html`)
- Banner de título
- **Formulário** de contato (não funcional)
- **Cards de informações** (Telefone, E-mail, Endereço, Horário)
- **Mapa** da localização
- CTA **WhatsApp**

---

## 🔁 O que se Repete em Todas as Páginas?

### ✅ HEADER (Cabeçalho)
- Logo da loja (`img/logo.png`)
- Menu de navegação (Início, Produtos, Contatos)
- Barra de pesquisa (visual, não funcional)

### ✅ FOOTER (Rodapé)
- Marca e descrição
- Ícones sociais (Instagram, YouTube, Email)
- Links de navegação
- Informações de atendimento
- Endereço e botão "Ver no mapa"
- Copyright

> 💡 **Dica de Estudo**: Compare os códigos do HEADER e FOOTER nas 3 páginas. Eles são IDÊNTICOS! Isso demonstra como a estrutura se mantém fixa enquanto apenas o conteúdo muda.

---

## 🎯 Efeitos Hover Implementados

| Elemento | Efeito |
|----------|--------|
| Links do menu | Barra laranja aparece embaixo |
| Botões primários | Ficam transparentes com borda laranja |
| Cards de serviço | Sobem 10px e sombra aumenta |
| Cards de produto | Sobem 8px, borda fica laranja, imagem dá zoom |
| Cards de equipe | Borda laranja aparece, sombra laranja |
| Ícones sociais | Aumentam 10%, fundo vira laranja |
| Cards de informação | Movem 5px para a direita |
| Imagens | Zoom de 5% ao passar o mouse |

---

## 🖼️ Imagens

Todas as imagens são da **internet** (Unsplash e outras fontes), conforme solicitado pelo professor.

A **logo** (`img/logo.png`) deve ser adicionada manualmente na pasta `img/`.

---

## 📚 Ícones

Utilizados ícones do **Google Fonts Material Symbols**, biblioteca gratuita recomendada pelo professor.

---

## 📝 Notas Importantes

- ✅ **Sem JavaScript** - Apenas HTML + CSS
- ✅ **Sem frameworks** - CSS puro
- ✅ **Formulário não funcional** - Apenas visual
- ✅ **Barra de pesquisa não funcional** - Apenas visual
- ✅ **Responsivo** - Adapta para telas menores (mobile)

---

Desenvolvido para fins educacionais 🎓
